package com.capgemini.bratu.util;



public class GenerateApplicantPassword {
	
	public static String generate() {
		final int PASSWORD_LENGTH = 5;
		StringBuffer sb = new StringBuffer();
		for (int x = 0; x < PASSWORD_LENGTH; x++) {
			sb.append((char) ((int) (Math.random() * 26) + 97));
		}
		return sb.toString();
	}

}
