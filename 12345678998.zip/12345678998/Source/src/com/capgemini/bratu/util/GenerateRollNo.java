package com.capgemini.bratu.util;

public class GenerateRollNo {
	
	public static String generate(String courseName) {
		String roll = "BR"+"12"+courseName;
		
		final int PASSWORD_LENGTH = 3;
		
		
		
		String sb = new String();
		for (int x = 0; x < PASSWORD_LENGTH; x++) {
			sb = sb + ( ((int) (Math.random() * 10)));
		}
		
		roll = roll + sb;
		
		return roll;
	}

}
