package com.capgemini.bratu.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.bratu.entities.Application;
import com.capgemini.bratu.exception.ApplicationException;
import com.capgemini.bratu.util.Status;



@Repository
public class ApplicationDaoImpl implements ApplicationDao{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@PersistenceContext
	EntityManager entityManager;
	@Override
	public Status save(Application application) throws ApplicationException {
		
		try {
			application.setRoll_no("Not Allotted");
			application.setStatus("Applied");
			entityManager.persist(application);
			
			
		} catch (Exception e) {
			throw new ApplicationException("Error Message : "+e.getMessage());
		}
		if(application.getApplication_id() != 0){
			return new Status(1, "Insertation Done", application);
		}
		else{
		return new Status(0, "Insertation failed", application);
		}
	}

	@Override
	public Status update(Application application) throws ApplicationException {
		
		Application app = null ;
		try {
			 app = entityManager.merge(application);
		} catch (Exception e) {
			throw new ApplicationException("Error Message : "+e.getMessage());
		}
	
		if(app == null){
			throw new ApplicationException("User not uppdated");
		}
		else{
			return new Status(1,"userUpdated", app);
		}
	
	}

	@Override
	public Status updateStatus(Application application)
			throws ApplicationException {
		
		return null;
	}

	@Override
	public Status updateInterview(Application application)
			throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Status findById(Application application) throws ApplicationException {
		
		long id = application.getApplication_id();
		Application applicationById = null ;
		try {
			
			applicationById = entityManager.find(Application.class, id);
			
		} catch (Exception e) {
			throw new ApplicationException("Error Message : "+e.getMessage());
		}
		if(applicationById != null ){
		return new Status(1,"Application Found", applicationById);
		}
		else{
			return new Status(0,"Application Not Found", applicationById);
		}
	}

	@Override
	public Status showAll() throws ApplicationException {
		
		List<Application> list = new ArrayList<Application>();
		TypedQuery<Application> query = entityManager.createQuery("Select a from Application a" , Application.class);
		try {
			 list = query.getResultList();
		} catch (Exception e) {
			throw new ApplicationException("Error Message : "+e.getMessage());
		}
		if(list != null){
		return new Status(1,"All Applications", list);
		}
		else{
			return new Status(0,"Applications Not Found", list);
		}
	}

	@Override
	public Status delete(Application application) throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Status findByStatus(Application application)
			throws ApplicationException {
		entityManager.flush();
		
		List<Application> list = new ArrayList<Application>();
		try {
			TypedQuery<Application> query = entityManager.createQuery("select a from Application a where "
					+ "status ='" +application.getStatus()+"' ", Application.class);
			
			 list = query.getResultList();
		} catch (Exception e) {
			throw new ApplicationException("Error Message : "+e.getMessage());
		}
	
		if(list != null){
		return new Status(1,"Status Based Application", list);
		}
		else{
			return new Status(0,"Application Not Found For this Status", list);
		}
	}

	@Override
	public Status findByEmail(Application application)
			throws ApplicationException {
		TypedQuery<Application> query = entityManager.createQuery("select a from Application a where "
				+ "email_id ='" +application.getEmail_id()+"' ", Application.class);
		
		return new Status(1, "", (Application) query.getSingleResult());
	}

}
