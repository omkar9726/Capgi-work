package com.capgemini.bratu.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.capgemini.bratu.entities.Program_Scheduled;

import com.capgemini.bratu.exception.ProgramScheduledException;
import com.capgemini.bratu.util.Status;

@Repository
public class ProgramScheduledDAOImpl implements ProgramScheduledDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

	@Override
	public Status save(Program_Scheduled program) {
		
		entityManager.persist(program);
		
		if (program.getScheduled_program_id() != 0) {
			
			return new Status(1, "Program Added Successfully", program);
			
		}else {
			return new Status(0, "Program Not Added", program);
		}
		
	}

	@Override
	public Status update(Program_Scheduled program) {
		
		return null;
	}

	@Override
	public Status delete(Program_Scheduled program) throws ProgramScheduledException {
		
		try {
			entityManager.remove(program);
			return new Status(1, "Program Deleted.", program);
		} catch (Exception e) {
			throw new ProgramScheduledException("Error Message : " + e.getMessage());
		}
	}

	@Override
	public Status findById(Program_Scheduled program) throws ProgramScheduledException {
		Program_Scheduled programByid = null;
		try {
			programByid = entityManager.find(Program_Scheduled.class, program.getScheduled_program_id());
		} catch (Exception e) {
			throw new ProgramScheduledException("Error Message : " + e.getMessage());
		}
		
		
		if (programByid != null) {
			
			return new Status(1, "Program Found", programByid);
		} else {
			return new Status(0, "Program Not Found", programByid);
		}
		
	}

	@Override
	public Status findByName(Program_Scheduled program) throws ProgramScheduledException {
	
		
		Program_Scheduled programnByName = null;
		
		try {
			
			TypedQuery<Program_Scheduled> query = entityManager.createQuery("SELECT p FROM Program_Scheduled p WHERE "
					+ "courseName = '"+program.getCourseName()+"' ", Program_Scheduled.class);
			programnByName = (Program_Scheduled) query.getSingleResult();
			
		} catch (Exception e) {
			throw new ProgramScheduledException("Error Message : " + e.getMessage());
		}
			
		if (programnByName != null) {
			return new Status(1, "Program Found", programnByName);
		} else {
			return new Status(0, "Program NotFound", programnByName);
		}
		
	}
	
	@Override
	public Status findByProgramName(Program_Scheduled program) throws ProgramScheduledException {
	
		
		List<Program_Scheduled> programnByName = null;
		
		try {
			
			TypedQuery<Program_Scheduled> query = entityManager.createQuery("SELECT p FROM Program_Scheduled p WHERE "
					+ "programName = '"+program.getProgramName()+"' ", Program_Scheduled.class);
			programnByName = (List<Program_Scheduled>) query.getResultList();
			
		} catch (Exception e) {
			throw new ProgramScheduledException("Error Message : " + e.getMessage());
		}
			
		if (programnByName != null) {
			return new Status(1, "Program Found", programnByName);
		} else {
			return new Status(0, "Program NotFound", programnByName);
		}
		
	}

	@Override
	public Status findAll() throws ProgramScheduledException{
		List<Program_Scheduled> programList = null;
		try {
			TypedQuery<Program_Scheduled> query = entityManager.createQuery("SELECT p FROM Program_Scheduled p", Program_Scheduled.class);
			programList = query.getResultList();
		} catch (Exception e) {
			throw new ProgramScheduledException("Error Message : " + e.getMessage());
		}
	
		if (programList != null) {
			return new Status(1, "Program List Found", programList);
		} else {
			return new Status(0, "Program List Not Found", programList);
		}
	
	}
	}


