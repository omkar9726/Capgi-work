package com.capgemini.bratu.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.bratu.entities.UserMaster;
import com.capgemini.bratu.exception.UserMasterException;
import com.capgemini.bratu.util.Status;

@Repository
public class UserMasterDAOImpl implements UserMasterDAO{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Status login(UserMaster user) throws UserMasterException {
	
		try {
			
			entityManager.flush();
			TypedQuery<UserMaster> query = entityManager.createQuery("SELECT u FROM UserMaster u WHERE "
					+ "login_id = '"+user.getLogin_id()+"' AND password = '"+user.getPassword()+"' ", UserMaster.class);
			
			UserMaster userById = (UserMaster) query.getSingleResult();
			
			if (userById == null) {
				// Logger
				throw new UserMasterException("User Not Found");
			} else{
				return new Status(1, "User Found", userById);
			}
			
		} catch(Exception e) {
			throw new UserMasterException("User Not Found");
		}
	
		
	
	}

	@Override
	public Status update(UserMaster user) throws UserMasterException {
		UserMaster updatedUser = entityManager.merge(user);
		if (updatedUser == null) {
			// Logger
			throw new UserMasterException("User Updated");
		} else{
			return new Status(1, "User  Updated", updatedUser);
		}
	
	}

	@Override
	public Status findByLoginId(UserMaster user) throws UserMasterException {
		
		TypedQuery<UserMaster> query = entityManager.createQuery("SELECT u FROM UserMaster u WHERE "
				+ "login_id = '"+user.getLogin_id()+"'  ", UserMaster.class);
		
		
		UserMaster userById = (UserMaster) query.getSingleResult();
		
		if (userById == null) {
			// Logger
			throw new UserMasterException("User Not Found");
		} else{
			return new Status(1, "User Found", userById);
		}
		
	}

	@Override
	public Status save(UserMaster user) throws UserMasterException {
		try {
			entityManager.persist(user);
		}catch (Exception e) {
			throw new UserMasterException("User Already Registered");
		}
		
		
		
		return new Status(1, "Saved", null);
	}

}
