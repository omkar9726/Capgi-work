package com.capgemini.bratu.repository;

import java.io.Serializable;

import com.capgemini.bratu.entities.ProgramOffered;
import com.capgemini.bratu.exception.ProgramOfferedException;
import com.capgemini.bratu.util.Status;

public interface ProgramOfferedDAO extends Serializable{

	public Status save(ProgramOffered program) throws ProgramOfferedException;
	
	public Status update(ProgramOffered program) throws ProgramOfferedException;
	
	public Status delete(ProgramOffered program) throws ProgramOfferedException;
	
	public Status findById(ProgramOffered program) throws ProgramOfferedException;
	
	public Status fingByName(ProgramOffered program) throws ProgramOfferedException;
	
	public Status findAll() throws ProgramOfferedException;
	
}
