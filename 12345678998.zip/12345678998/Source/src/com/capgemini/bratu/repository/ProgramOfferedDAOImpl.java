package com.capgemini.bratu.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.bratu.entities.ProgramOffered;
import com.capgemini.bratu.exception.ProgramOfferedException;
import com.capgemini.bratu.util.Status;


@Repository
public class ProgramOfferedDAOImpl implements ProgramOfferedDAO {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Status save(ProgramOffered program) throws ProgramOfferedException {
		
		try {
		entityManager.persist(program);
		} catch (Exception e) {
			throw new ProgramOfferedException("Error Message : " + e.getMessage());
		}
		
		
		if (program.getId() != 0) {
			
			return new Status(1, "Program Added Successfully", program);
			
		}else {
			return new Status(0, "Program Not Added", program);
		}
		
		
	}

	@Override
	public Status update(ProgramOffered program) throws ProgramOfferedException {
		
		ProgramOffered updatedProgram = null;
		try {
			updatedProgram = entityManager.merge(program);
		} catch (Exception e) {
			
		}
		if (updatedProgram != null) {
			return new Status(1, "Program Updated.", updatedProgram);
		} else {
			return new Status(0, "Program Not Updated.", updatedProgram);
		}
	
	}

	@Override
	public Status delete(ProgramOffered program) throws ProgramOfferedException {
	
		try {
			entityManager.remove(program);
			return new Status(1, "Program Deleted.", program);
		} catch (Exception e) {
			throw new ProgramOfferedException("Error Message : " + e.getMessage());
		}
	}

	@Override
	public Status findById(ProgramOffered program)
			throws ProgramOfferedException {
		
		ProgramOffered programByid = null;
		try {
			programByid = entityManager.find(ProgramOffered.class, program.getId());
		} catch (Exception e) {
			throw new ProgramOfferedException("Error Message : " + e.getMessage());
		}
		
		
		if (programByid != null) {
			
			return new Status(1, "Program Found", programByid);
		} else {
			return new Status(0, "Program Not Found", programByid);
		}
		
		
	}

	@Override
	public Status fingByName(ProgramOffered program)
			throws ProgramOfferedException {
		
		ProgramOffered programnByName = null;
		
		try {
			
			TypedQuery<ProgramOffered> query = entityManager.createQuery("SELECT p FROM ProgramOffered p WHERE "
					+ "programName = '"+program.getProgramName()+"' ", ProgramOffered.class);
			programnByName = (ProgramOffered) query.getSingleResult();
			
		} catch (Exception e) {
			throw new ProgramOfferedException("Error Message : " + e.getMessage());
		}
			
		if (programnByName != null) {
			return new Status(1, "Program Found", programnByName);
		} else {
			return new Status(0, "Program NotFound", programnByName);
		}
		
	}

	@Override
	public Status findAll() throws ProgramOfferedException {
	
		List<ProgramOffered> programList = null;
		try {
			TypedQuery<ProgramOffered> query = entityManager.createQuery("SELECT p FROM ProgramOffered p", ProgramOffered.class);
			programList = query.getResultList();
		} catch (Exception e) {
			throw new ProgramOfferedException("Error Message : " + e.getMessage());
		}
	
		if (programList != null) {
			return new Status(1, "Program List Found", programList);
		} else {
			return new Status(0, "Program List Not Found", programList);
		}
	
	}

}
