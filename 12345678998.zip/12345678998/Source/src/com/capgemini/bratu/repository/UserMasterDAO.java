package com.capgemini.bratu.repository;

import java.io.Serializable;

import com.capgemini.bratu.entities.UserMaster;
import com.capgemini.bratu.exception.UserMasterException;
import com.capgemini.bratu.util.Status;

public interface UserMasterDAO extends Serializable {
	
	public Status login(UserMaster user) throws UserMasterException;
	
	public Status update(UserMaster user) throws UserMasterException;
	
	public Status findByLoginId(UserMaster user) throws UserMasterException;
	
	public Status save(UserMaster user) throws UserMasterException;

}
