/*package com.capgemini.bratu.test;

import static org.junit.Assert.*;

import java.util.Date;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;


import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.bratu.entities.Application;
import com.capgemini.bratu.entities.UserMaster;
import com.capgemini.bratu.exception.ApplicationException;
import com.capgemini.bratu.exception.UserMasterException;
import com.capgemini.bratu.repository.ApplicationDao;
import com.capgemini.bratu.service.ApplicationService;
import com.capgemini.bratu.service.UserMasterService;
import com.capgemini.bratu.util.Status;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/jpaContext.xml")
@ActiveProfiles("oracle")
public class TestApplication {

	UserMaster actual = new UserMaster();
	UserMaster expected = new UserMaster();
	
	
	@Autowired
	ApplicationService appdao;
	
	
	Application application = new Application();
	@Before
	public void setUp(){
	
		application.setApplication_id(1);
		application.setCourseName("btech");
		application.setDate_of_birth("12/12/2013");
		application.setEmail_id("vinod.com");
		application.setFull_name("vinodShukla");
		application.setGoals("cricket");
		application.setHighest_qualification("hsc");
		application.setMarks_obtained(12d);
		application.setRoll_no("21244");
		application.setScheduled_program_id(1l);
		application.setStatus("applied");	
	}
	
	
	@Test
	public void testSave() throws ApplicationException, UserMasterException {
		
		
		Status status =appdao.save(application);
		boolean flag = false;
		if(status.getCode()==1){
			flag = true ;
		}
		assertTrue(flag);
		
	}

	@Test
	public void testFindAll() throws ApplicationException{
		Status status =appdao.showAll();
		
		boolean flag = false ;
		if(status.getCode()==1){
			flag = true ;
		}
		assertTrue(flag);
	}
	
	@Test
	public void testFindById() throws ApplicationException{
		
		Application app1 = new Application();
		app1.setApplication_id(8);
		Status status = appdao.findById(app1);
		boolean flag = false ;
		if(status.getCode()==1){
			flag= true ;
		
	}
		assertTrue(flag);
}
	
}
*/