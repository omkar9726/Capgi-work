package com.capgemini.bratu.controller;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;





















import com.capgemini.bratu.entities.Application;
import com.capgemini.bratu.entities.ProgramOffered;
import com.capgemini.bratu.entities.Program_Scheduled;
import com.capgemini.bratu.entities.UserMaster;
import com.capgemini.bratu.exception.ApplicationException;
import com.capgemini.bratu.exception.ProgramOfferedException;
import com.capgemini.bratu.exception.ProgramScheduledException;
import com.capgemini.bratu.exception.UserMasterException;
import com.capgemini.bratu.service.ApplicationService;
import com.capgemini.bratu.service.ProgramOfferedService;
import com.capgemini.bratu.service.ProgramScheduledService;
import com.capgemini.bratu.service.UserMasterService;
import com.capgemini.bratu.util.GenerateApplicantPassword;
import com.capgemini.bratu.util.GenerateRollNo;
import com.capgemini.bratu.util.Status;


@Controller
public class MainController {
	
	@Autowired
	UserMasterService userMasterService;
	
	@Autowired
	ProgramOfferedService programOfferedService;
	
	@Autowired
	ProgramScheduledService programScheduledService;
	
	@Autowired
	ApplicationService applicationService;
	

	
	
	
	@RequestMapping(value="/index")
	public String sendToHomePage() {
		return "index";
	}
	
	@RequestMapping(value="/loginRequest")
	public String loginRequest(Model model, HttpServletRequest req) {
		/*String errorMessage = req.getParameter("errorMessage");
		if () {
			
		}*/
		model.addAttribute("user", new UserMaster());
		return "Login";
	}
	
	
	@RequestMapping(value="/register")
	public String register(Model model) {
		
		try {
			Status status = programOfferedService.findAll();
			@SuppressWarnings("unchecked")
			List<ProgramOffered> listProgram = (List<ProgramOffered>) status.getObject();
			if(listProgram.size() != 0){
				model.addAttribute("programList", listProgram);
			}else{
				model.addAttribute("programList", null);
			}
			model.addAttribute("applicant", new Application());
			
			return "entryForm";
		} catch (ProgramOfferedException e) {
			model.addAttribute("errorMsg", "Please Login First");
			return "redirect:/index.html";
		}
	
		
	}
	
	
	@RequestMapping(value="/openEntryForm", method=RequestMethod.POST)
	public String openEntryForm(Model model, HttpServletRequest req) {
	

		
		try {
			
			String programId = req.getParameter("chooseProgram");
			Long progId = Long.parseLong(programId);
			ProgramOffered program = new ProgramOffered();
			program.setId(progId);
			Status status1 = programOfferedService.findById(program);
			ProgramOffered programById = (ProgramOffered) status1.getObject();
			
			Program_Scheduled schProg = new Program_Scheduled();
			schProg.setProgramName(programById.getProgramName());
			
			Status schStatus = programScheduledService.findByProgramName(schProg);
			
			List<Program_Scheduled> schProgByName = (List<Program_Scheduled>) schStatus.getObject();
			String[] courseName = new String[schProgByName.size()];
			for(int i = 0; i < schProgByName.size(); i++) {
				courseName[i] = schProgByName.get(i).getCourseName();
			}
			
			System.out.println(courseName);
			
			model.addAttribute("progListByName", courseName);
			String[] minQua = programById.getApplicant_eligibility().split(",");
			
			Status status = programOfferedService.findAll();
			@SuppressWarnings("unchecked")
			List<ProgramOffered> listProgram = (List<ProgramOffered>) status.getObject();
			model.addAttribute("roles",minQua);
			model.addAttribute("applicant", new Application());
			model.addAttribute("id", programById.getId());
			model.addAttribute("programList", listProgram);
			return "entryForm";
		} catch (ProgramOfferedException | ProgramScheduledException e) {
			model.addAttribute("errorMsg", "Please Login First");
			return "redirect:/index.html";
		}
	
		
	}
	
	
	@RequestMapping(value="/adminLogout")
	public String logout(Model model , HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		if (session != null) {
			UserMaster user = (UserMaster) session.getAttribute("user");
			try {
				user.setLastLogin(new Date());
				
				UserMaster userLoggedOut = new UserMaster();
				userLoggedOut.setId(user.getId());
				userLoggedOut.setLastLogin(new Date());
				userLoggedOut.setLogin_id(user.getLogin_id());
				userLoggedOut.setPassword(user.getPassword());
				userLoggedOut.setRole(user.getRole());
				
				userMasterService.update(userLoggedOut);
				session.invalidate();
				return "redirect:/index.html";
			} catch (UserMasterException e) {
				model.addAttribute("errorMsg", "Please Login First");
				return "redirect:/index.html";
			}
			
		} else {
			model.addAttribute("errorMsg", "Please Login First");
			return "redirect:/index.html";
		}
		
	}
	
	
	@RequestMapping(value="/applicantLogout")
	public String applicantLogout(Model model , HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		if (session != null) {
			UserMaster user = (UserMaster) session.getAttribute("applicant");
			try {
				
				UserMaster userLoggedOut = new UserMaster();
				userLoggedOut.setLogin_id(user.getLogin_id());
				
				Status status = userMasterService.findByLoginId(userLoggedOut);
				UserMaster userToLogOut = (UserMaster) status.getObject();
				userToLogOut.setFirstLogin("N");
				userToLogOut.setLastLogin(new Date());
				userMasterService.update(userToLogOut);
				session.invalidate();
				return "redirect:/index.html";
			} catch (UserMasterException e) {
				model.addAttribute("errorMsg", "Please Login First");
				return "redirect:/index.html";
			}
			
		} else {
			model.addAttribute("errorMsg", "Please Login First");
			return "redirect:/index.html";
		}
		
	}
	
	
	@RequestMapping(value="/MACLogout")
	public String MACLogout(Model model , HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		if (session != null) {
			UserMaster user = (UserMaster) session.getAttribute("MAC");
			try {
				
				UserMaster userLoggedOut = new UserMaster();
				userLoggedOut.setLogin_id(user.getLogin_id());
			
				Status status = userMasterService.findByLoginId(userLoggedOut);
				UserMaster userToLogOut = (UserMaster) status.getObject();
				userToLogOut.setFirstLogin("N");
				userToLogOut.setLastLogin(new Date());
				userMasterService.update(userToLogOut);
				userMasterService.update(userLoggedOut);
				session.invalidate();
				return "redirect:/index.html";
			} catch (UserMasterException e) {
				model.addAttribute("errorMsg", "Please Login First");
				return "redirect:/index.html";
			}
			
		} else {
			model.addAttribute("errorMsg", "Please Login First");
			return "redirect:/index.html";
		}
		
	}
	
	
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String login(@ModelAttribute("user") UserMaster user, Model model, HttpServletRequest req) {
		UserMaster loggedUser = null;
		
		try {
			Status status = userMasterService.login(user);
			if (status.getCode() == 1) {
				loggedUser = (UserMaster) status.getObject();
				
				if (loggedUser.getRole().equalsIgnoreCase("ADMIN")) {
					HttpSession session = req.getSession(true);
					session.setAttribute("user", loggedUser);
					return "redirect:/adminHome.html";
				}
				
				if (loggedUser.getRole().equalsIgnoreCase("MAC")) {
					
					HttpSession session = req.getSession(true);
					session.setAttribute("MAC", loggedUser);
					
					if (loggedUser.getFirstLogin().equalsIgnoreCase("Y")) {
						
						model.addAttribute("loginId", loggedUser.getLogin_id());
						return "firstLoginMAC";
					}
					
					return "redirect:/MACHome.html";
					
				}
				
				if (loggedUser.getRole().equalsIgnoreCase("APPLICANT")) {
					
					HttpSession session = req.getSession(true);
					session.setAttribute("applicant", loggedUser);
					
					if (loggedUser.getFirstLogin().equalsIgnoreCase("Y")) {
						
						model.addAttribute("loginId", loggedUser.getLogin_id());
						return "firstLoginApplicant";
					}
					
					return "redirect:/applicantHome.html";
				}
			}
		} catch (UserMasterException e) {
			model.addAttribute("errorMessage", "Invalid Credentials");
		//	req.setAttribute("errorMessage", "Invalid Credentials");
			return "redirect:/loginRequest.html";
		}
		
		
		return "Login";
	}
	
	// ##################################################################  ADMIN Controller Methods  ######################################################################
	
	
	
	
	@RequestMapping(value="/saveUserMac")
	public String saveUserMac(@ModelAttribute("user") UserMaster user, Model model, HttpServletRequest req) {

		user.setFirstLogin("Y");
		user.setRole("MAC");
		try {
			Status statusByUser = userMasterService.login(user);
			if (statusByUser.getCode() == 1) {
				model.addAttribute("errorMessage", "User Already Registered");
				model.addAttribute("user", new UserMaster());
				return "addMacUser";
			} else {
				userMasterService.save(user);
			}
			
			return "redirect:/adminHome.html";
		} catch (UserMasterException e) {
			
			String errorMsg = "Not Able To Add , Error - " + e.getMessage();
			model.addAttribute("errorMsg", errorMsg);
			return "redirect:/adminHome.html";
		}
		
	}
	
	
	
	
	
	@RequestMapping(value="/adminHome")
	public String adminHome(@ModelAttribute("user") UserMaster user, Model model, HttpServletRequest req) {

		HttpSession session = req.getSession(false);
		
		if (session != null) {
			user = (UserMaster) session.getAttribute("user");
			model.addAttribute("user", user);
			return "adminHome";
		} else {
			return "redirect:/index.html";
		}
		
	}
	
	
	@RequestMapping(value="/addOffProg", method=RequestMethod.POST)
	public String addOffProg(HttpServletRequest req, Model model) {	
		
		HttpSession session = req.getSession(false);
		UserMaster user = (UserMaster) session.getAttribute("user");
		
		model.addAttribute("user", user);
		model.addAttribute("program", new ProgramOffered());
		
		return "addOfferedProgram";
	}
	
	
	@RequestMapping(value="/saveOffProg", method=RequestMethod.POST)
	public String saveOffProg(@ModelAttribute("program") ProgramOffered program, Model model) {	
		
		try {
			Status status = programOfferedService.save(program);
			if (status.getCode() == 1) {
				
				String successMsg = "Program Added Successfully";
				model.addAttribute("successMsg", successMsg);
				return "redirect:/adminHome.html";
			} else {
				String errorMsg = "Not Able To Add , Error - " + status.getMessage();
				model.addAttribute("errorMsg", errorMsg);
				return "redirect:/adminHome.html";
			}
		} catch (ProgramOfferedException e) {
			String errorMsg = "Not Able To Add , Error - " + e.getMessage();
			model.addAttribute("errorMsg", errorMsg);
			return "redirect:/adminHome.html";
		}
		
		
	}
	
	
	@RequestMapping(value="/showProg", method=RequestMethod.POST)
	public String showProgList(Model model, HttpServletRequest req) {
		String programType = req.getParameter("chooseProgram");
		
		switch (programType) {
		
		case "programOffered" : {
			
		try {
			Status status = programOfferedService.findAll();
			
			if (status.getCode() == 1) {
				@SuppressWarnings("unchecked")
				List<ProgramOffered> programList = (List<ProgramOffered>) status.getObject();
				HttpSession session = req.getSession(false);
				UserMaster user = (UserMaster) session.getAttribute("user");
				model.addAttribute("user", user);
				if (programList.size() != 0) {
					model.addAttribute("programList", programList);
				}else {
					model.addAttribute("programList", null);
				}
				
				return "showOfferedProgram";
			}
			
		} catch (ProgramOfferedException e) {
			model.addAttribute("errorMsg", "Please Login First");
			return "redirect:/adminHome.html";
		}
			
			break;
		}
		
		case "scheduledOffered" : {
			
			
			try {
				Status status = programScheduledService.findAll();
				
				if (status.getCode() == 1) {
					@SuppressWarnings("unchecked")
					List<Program_Scheduled> programList = (List<Program_Scheduled>) status.getObject();
					HttpSession session = req.getSession(false);
					UserMaster user = (UserMaster) session.getAttribute("user");
					model.addAttribute("user", user);
					
					if (programList.size() != 0) {
						model.addAttribute("programScheduledList", programList);
					}else {
						model.addAttribute("programScheduledList", null);
					}
					
					
					return "showProgramScheduled";
				}
				
			} catch (ProgramScheduledException e) {
				model.addAttribute("errorMsg", "Please Login First");
				return "redirect:/adminHome.html";
			}
			
			break;
		} 
		
		case "addMac" : {
			
			model.addAttribute("user", new UserMaster());
			
			return "addMacUser";
			
			
			
		}
		
		}
		
		return null;
		
		
	}
	
	
	@RequestMapping(value="/requestToEditOffProg")
	public String requestToEditOffProg(ProgramOffered program, Model model, HttpServletRequest req) {
		
		ProgramOffered programById = null;
		
		try {
			Status status = programOfferedService.findById(program);
			programById = (ProgramOffered) status.getObject();
			
			model.addAttribute("programById", programById);
			
			HttpSession session = req.getSession(false);
			UserMaster user = (UserMaster) session.getAttribute("user");
			
			model.addAttribute("user", user);
			model.addAttribute("program", new ProgramOffered());
			return "programOfferedUpdate";
			
		} catch (ProgramOfferedException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/adminHome.html";
		}

	}
	
	
	
	@RequestMapping(value="/requestToDeleteOffProg")
	public String requestToDeleteOffProg(ProgramOffered program, Model model, HttpServletRequest req) {
		
		try {
			programOfferedService.delete(program);
			return "redirect:/adminHome.html";
			
		} catch (ProgramOfferedException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/adminHome.html";
		}

	}
	
	
	
	@RequestMapping(value="/updateOffProg", method=RequestMethod.POST)
	public String updateOffProg(ProgramOffered program, Model model, HttpServletRequest req) {
		
		try {
			Status status = programOfferedService.update(program);
			
			if (status.getCode() == 1) {
				String message = "Program Updated Successfully";
				model.addAttribute("successMsg", message);
				return "redirect:/adminHome.html";
			} else {
				model.addAttribute("errorMsg", status.getMessage());
				return "redirect:/adminHome.html";
			}
			
		} catch (ProgramOfferedException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/adminHome.html";
		}
		
		
	}
	
	
	@RequestMapping(value="/addSchProg", method=RequestMethod.POST)
	public String addSchProg(HttpServletRequest req, Model model) {	
		
		HttpSession session = req.getSession(false);
		UserMaster user = (UserMaster) session.getAttribute("user");
		Status status;
		try {
			status = programOfferedService.findAll();
			@SuppressWarnings("unchecked")
			List<ProgramOffered> listProgram = (List<ProgramOffered>) status.getObject();
			model.addAttribute("programList", listProgram);
		} catch (ProgramOfferedException e) {
			
			e.printStackTrace();
		}
		model.addAttribute("user", user);
		Program_Scheduled programScheduled = new Program_Scheduled();
		model.addAttribute("program", programScheduled);
		
		return "addSchProgram";
	}
	

	
	
	@RequestMapping(value="/saveSchProg", method=RequestMethod.POST)
	public String saveSchProg(@ModelAttribute("program") Program_Scheduled program, Model model, HttpServletRequest req) {	
		
		try {
			String progName = req.getParameter("chooseProgram");
			program.setProgramName(progName);
			
			Status status = programScheduledService.save(program);
			if (status.getCode() == 1) {
				
				String successMsg = "Program Added Successfully";
				model.addAttribute("successMsg", successMsg);
				return "redirect:/adminHome.html";
			} else {
				String errorMsg = "Not Able To Add , Error - " + status.getMessage();
				model.addAttribute("errorMsg", errorMsg);
				return "redirect:/adminHome.html";
			}
		} catch (ProgramScheduledException e ) {
			String errorMsg = "Not Able To Add , Error - " + e.getMessage();
			model.addAttribute("errorMsg", errorMsg);
			return "redirect:/adminHome.html";
		}
		
		
	}
	
	
	
	@RequestMapping(value="/requestToEditSchProg")
	public String requestToEditSchProg(Program_Scheduled program, Model model, HttpServletRequest req) {
		
		Program_Scheduled programById = null;
		
		try {
			Status status = programScheduledService.findById(program);
			programById = (Program_Scheduled) status.getObject();
			
			model.addAttribute("programById", programById);
			
			HttpSession session = req.getSession(false);
			UserMaster user = (UserMaster) session.getAttribute("user");
			
			model.addAttribute("user", user);
			Program_Scheduled programScheduled = new Program_Scheduled();
			model.addAttribute("program", programScheduled);
			return "programSchUpdate";
			
		} catch (ProgramScheduledException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/adminHome.html";
		}

	}
	
	
	
	
	
	@RequestMapping(value="/updateSchProg", method=RequestMethod.POST)
	public String updateSchProg(Program_Scheduled program, Model model, HttpServletRequest req) {
		
		try {
			Status status = programScheduledService.update(program);
			
			if (status.getCode() == 1) {
				String message = "Program Updated Successfully";
				model.addAttribute("successMsg", message);
				return "redirect:/adminHome.html";
			} else {
				model.addAttribute("errorMsg", status.getMessage());
				return "redirect:/adminHome.html";
			}
			
		} catch (ProgramScheduledException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/adminHome.html";
		}
		
		
	}
	
	
	
	@RequestMapping(value="/requestToDeleteSchProg")
	public String requestToDeleteSchProg(Program_Scheduled program, Model model, HttpServletRequest req) {
		
		try {
			programScheduledService.delete(program);
			return "redirect:/adminHome.html";
			
		} catch (ProgramScheduledException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/adminHome.html";
		}

	}
	

	
	// ##########################################################################################################################################################
	
	
	
	
	// ################################################################################# Applicant #################################################################################
	
	
	
	
	@RequestMapping(value="/applicantHome")
	public String applicantHome(@ModelAttribute("user") UserMaster user, Model model, HttpServletRequest req) {

		HttpSession session = req.getSession(false);
		System.out.println(session);
		if (session != null) {
			UserMaster userBySession = (UserMaster) session.getAttribute("applicant");
			Application application = new Application();
			application.setEmail_id(userBySession.getLogin_id());
			
		
			
			
			try {
				
			
			
				//model.addAttribute("course", applicatiobByEmail.getCourseName());
				//model.addAttribute("progName", progById.getProgramName());
				
				Status status = applicationService.findByEmail(application);
				Application applicationByEmail = (Application) status.getObject();
				model.addAttribute("userApplicant", applicationByEmail);
				Program_Scheduled program = new Program_Scheduled();
				/*Status schStatus = programScheduledService.findByProgramName(program);
				
				Program_Scheduled schProgramByName = (Program_Scheduled) schStatus.getObject();
				*/
				
				program.setCourseName(applicationByEmail.getCourseName());
				
				Status schProStatus = programScheduledService.findByName(program);
				Program_Scheduled prog = (Program_Scheduled) schProStatus.getObject();
				
				model.addAttribute("offProgName", prog.getProgramName());
				
				return "applicantHome";
				
			} catch (ApplicationException | ProgramScheduledException e) {
				model.addAttribute("errorMsg", e.getMessage());
				return "redirect:/applicantHome.html";
			}
			
		
		} else {
			return "redirect:/index.html";
		}
		
	}
	
	
	
	@RequestMapping(value="/registerForm", method=RequestMethod.POST)
	public String registerForm(Application application, Model model, HttpServletRequest req) {
		
		try {
			
			Status status = applicationService.save(application);
			if (status.getCode() == 1) {
				
				String pssword = GenerateApplicantPassword.generate();
				model.addAttribute("pass", pssword);
				model.addAttribute("loginId", application.getEmail_id());
				UserMaster user = new UserMaster();
				user.setPassword(pssword);
				user.setLogin_id(application.getEmail_id());
				user.setFirstLogin("Y");
				user.setRole("APPLICANT");
				@SuppressWarnings("unused")
				Status saveUser = userMasterService.save(user);
				return "showRegisterPassword";
			} else {
				model.addAttribute("errorMsg", status.getMessage());
				return "redirect:/register.html";
			}
			
		} catch (ApplicationException | UserMasterException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/register.html";
		}
		
		
	}
	
	@RequestMapping(value="/updatePassApp", method=RequestMethod.POST)
	public String updatePassApp(@ModelAttribute("user") UserMaster user, Model model, HttpServletRequest req) {

		try {
			user.setFirstLogin("N");
			
			user.setLastLogin(new Date());
			
			userMasterService.update(user);
			return "redirect:/applicantHome.html";
		} catch (UserMasterException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/applicantHome.html";
		}
		
	
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping(value="/editApplication")
	public String editApplication(Application application, Model model, HttpServletRequest req) {
		
		Application applicationById = null;
		
		try {
			Status status = applicationService.findById(application);
			applicationById = (Application) status.getObject();
			
			model.addAttribute("applicationById", applicationById);
			
			HttpSession session = req.getSession(false);
			UserMaster user = (UserMaster) session.getAttribute("applicant");
			
			model.addAttribute("applicant", user);
			model.addAttribute("application", new Application());
			return "editApplication";
			
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/applicantHome.html";
		}

	}
	
	
	
	
	@RequestMapping(value="/updateApplication", method=RequestMethod.POST)
	public String updateApplication(@ModelAttribute("application") Application application, Model model, HttpServletRequest req) {

		try {
			applicationService.update(application);
			return "redirect:/applicantHome.html";
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/applicantHome.html";
		}
		
	
		
		
	}
	
	
	
	// #####################################################################################################################################################################
	
	
	
	
	// ###################################################################################### MAC ########################################################################
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/showListByStatus")
	public String showListByStatus(Model model, HttpServletRequest req) {

		String statusType = req.getParameter("selectStatus");
		
		if (statusType.equalsIgnoreCase("Applied") || statusType.equalsIgnoreCase("Reject")) {
			List<Application> List = null;
			Application application = new Application();
			application.setStatus(statusType);
			Status status;
			try {
				HttpSession session = req.getSession(false);
				UserMaster user = (UserMaster) session.getAttribute("MAC");
				model.addAttribute("MAC", user);
				status = applicationService.findByStatus(application);
				List = (List<Application>) status.getObject();
				model.addAttribute("applicationList", List);
				return "MACHome";
			} catch (ApplicationException e) {
				return "index";
			}
		}
		
		if (statusType.equalsIgnoreCase("Accepted")) {
			
			List<Application> List = null;
			Application application = new Application();
			application.setStatus(statusType);
			Status status;
			try {
				HttpSession session = req.getSession(false);
				UserMaster user = (UserMaster) session.getAttribute("MAC");
				model.addAttribute("MAC", user);
				status = applicationService.findByStatus(application);
				List = (List<Application>) status.getObject();
				model.addAttribute("applicationList", List);
				return "acceptedApplicantList";
			} catch (ApplicationException e) {
				return "index";
			}
		}
		
		
		if (statusType.equalsIgnoreCase("Confirmed")) {
			
			List<Application> List = null;
			Application application = new Application();
			application.setStatus(statusType);
			Status status;
			try {
				HttpSession session = req.getSession(false);
				UserMaster user = (UserMaster) session.getAttribute("MAC");
				model.addAttribute("MAC", user);
				status = applicationService.findByStatus(application);
				List = (List<Application>) status.getObject();
				model.addAttribute("applicationList", List);
				return "confirmedApplicantList";
			} catch (ApplicationException e) {
				return "index";
			}
		}
		
		
		return null;
		
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/MACHome")
	public String MACHome(Model model, HttpServletRequest req) {

		List<Application> appliedList = null;
		Application application = new Application();
		application.setStatus("Applied");
		Status status;
		try {
			HttpSession session = req.getSession(false);
			UserMaster user = (UserMaster) session.getAttribute("MAC");
			model.addAttribute("MAC", user);
			status = applicationService.findByStatus(application);
			appliedList = (List<Application>) status.getObject();
			model.addAttribute("applicationList", appliedList);
			return "MACHome";
		} catch (ApplicationException e) {
			return "index";
		}

		
	}
	
	
	@RequestMapping(value="/updatePassMAC", method=RequestMethod.POST)
	public String updatePassMAC(@ModelAttribute("user") UserMaster user, Model model, HttpServletRequest req) {

		try {
			user.setFirstLogin("N");
			user.setLastLogin(new Date());
			userMasterService.update(user);
			return "redirect:/MACHome.html";
		} catch (UserMasterException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/MACHome.html";
		}
		
	}
	
	@RequestMapping(value="/viewMacApplication")
	public String viewMacApplication( Application application, Model model, HttpServletRequest req) {

		try {
			HttpSession session = req.getSession(false);
			UserMaster user = (UserMaster) session.getAttribute("MAC");
			model.addAttribute("MAC", user);
			Status status = applicationService.findById(application);
			Application applicationById = (Application) status.getObject();
			model.addAttribute("applicationById", applicationById);
			model.addAttribute("application", new Application());
			
			return "viewApplication";
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/MACHome.html";
		}
		
		
		
	}
	
	
	
	@RequestMapping(value="/setDOI", method=RequestMethod.POST)
	public String setDOI(@ModelAttribute("application") Application application, Model model, HttpServletRequest req) {

		try {
			application.setStatus("Accepted");
			applicationService.update(application);
			return "redirect:/MACHome.html";
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/MACHome.html";
		}
	}
	
	
	
	
	@RequestMapping(value="/rejectAppliedApplication")
	public String rejectAppliedApplication( Application application, Model model, HttpServletRequest req) {

		try {
			application.setStatus("Reject");
			applicationService.update(application);
			return "redirect:/MACHome.html";
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/MACHome.html";
		}
	}
	
	
	@RequestMapping(value="/rejectAcceptedApplication")
	public String rejectAcceptedApplication( Application application, Model model, HttpServletRequest req) {

		try {
			application.setStatus("Reject");
			applicationService.update(application);
			return "redirect:/MACHome.html";
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/MACHome.html";
		}
	}
	
	@RequestMapping(value="/confirmeAcceptedApplication")
	public String confirmeAcceptedApplication( Application application, Model model, HttpServletRequest req) {

		try {
			application.setStatus("Confirmed");
			
			Status status = applicationService.findById(application);
			
			Application  applicationById = (Application) status.getObject();
			
			String rollNo = GenerateRollNo.generate(applicationById.getCourseName());
			application.setRoll_no(rollNo);
			applicationService.update(application);
			return "redirect:/MACHome.html";
		} catch (ApplicationException e) {
			model.addAttribute("errorMsg", e.getMessage());
			return "redirect:/MACHome.html";
		}
	}
	
	
	// ###################################################################################################################################################################
	
	
	
	
	
	
	
	
}
