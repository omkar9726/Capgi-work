package com.capgemini.bratu.exception;

public class ProgramScheduledException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProgramScheduledException() {
		super();
	}

	public ProgramScheduledException(String message) {
		super(message);
	}
	
	

}
