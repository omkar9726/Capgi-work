package com.capgemini.bratu.exception;

public class ProgramOfferedException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProgramOfferedException() {
		super();
	}

	public ProgramOfferedException(String message) {
		super(message);
	}
	
	

}
