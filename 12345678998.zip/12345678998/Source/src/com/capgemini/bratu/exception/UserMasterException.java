package com.capgemini.bratu.exception;

public class UserMasterException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserMasterException() {
		super();
	}

	public UserMasterException(String message) {
		super(message);
	}
	
	

}
