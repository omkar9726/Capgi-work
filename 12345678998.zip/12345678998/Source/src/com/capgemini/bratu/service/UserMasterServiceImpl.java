package com.capgemini.bratu.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bratu.entities.UserMaster;
import com.capgemini.bratu.exception.UserMasterException;
import com.capgemini.bratu.repository.UserMasterDAO;
import com.capgemini.bratu.util.Status;


@Service
@Transactional
public class UserMasterServiceImpl implements UserMasterService {
	
	@Autowired
	UserMasterDAO userMasterDao;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public Status login(UserMaster user) throws UserMasterException {
		Status status = userMasterDao.login(user);
		
		if (status.getCode() == 1) {
			return new Status(1, "User Found", (UserMaster) status.getObject());
		} else {
			return new Status(0, "User Not Found", (UserMaster) status.getObject());
		}
		
	}

	@Override
	public Status update(UserMaster user) throws UserMasterException {
		Status status = userMasterDao.findByLoginId(user);
		UserMaster userById = (UserMaster) status.getObject();
		
		if (user.getFirstLogin() != null) {	
			userById.setFirstLogin(user.getFirstLogin());
		}
		
		if (user.getLastLogin() != null) {
			userById.setLastLogin(user.getLastLogin());
		}
		
		if (user.getPassword() != null) {
			userById.setPassword(user.getPassword());
		}

		if (user.getRole() != null) {
			userById.setRole(user.getRole());
		}
		Status updatedUser = userMasterDao.update(userById);
		
		if (updatedUser.getCode() == 1) {
			
			return  updatedUser;
			
		} else {
			throw new UserMasterException("Not Updated");
		}
	}

	@Override
	public Status save(UserMaster user) throws UserMasterException {
		return userMasterDao.save(user);
	}

	@Override
	public Status findByLoginId(UserMaster user) throws UserMasterException {
		
		return userMasterDao.findByLoginId(user);
	}

}
