package com.capgemini.bratu.service;

import java.io.Serializable;

import com.capgemini.bratu.entities.Application;
import com.capgemini.bratu.exception.ApplicationException;
import com.capgemini.bratu.util.Status;

public interface ApplicationService extends Serializable {

	
	public Status save(Application application) throws ApplicationException;
	
	public Status update(Application application) throws ApplicationException;
	
	public Status updateStatus(Application application) throws ApplicationException;
	
	public Status updateInterview(Application application) throws ApplicationException;
	
	public Status findById(Application application) throws ApplicationException;
	
	public Status showAll() throws ApplicationException ;
	
	public Status findByEmail(Application application) throws ApplicationException;
	
	public Status delete(Application application) throws ApplicationException;
	
	public Status findByStatus(Application application) throws ApplicationException;
}
