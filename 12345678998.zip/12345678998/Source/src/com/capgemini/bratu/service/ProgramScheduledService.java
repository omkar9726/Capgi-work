package com.capgemini.bratu.service;

import java.io.Serializable;

import com.capgemini.bratu.entities.Program_Scheduled;
import com.capgemini.bratu.exception.ProgramScheduledException;
import com.capgemini.bratu.util.Status;

public interface ProgramScheduledService extends Serializable {
	
	public Status save(Program_Scheduled program)throws ProgramScheduledException;
	
	public Status update(Program_Scheduled program)throws ProgramScheduledException;
	
	public Status delete(Program_Scheduled program) throws ProgramScheduledException;
	
	public Status findById(Program_Scheduled program)throws ProgramScheduledException;
	
	public Status findByName(Program_Scheduled program)throws ProgramScheduledException;
	
	public Status findAll()throws ProgramScheduledException;
	
	Status findByProgramName(Program_Scheduled program)
			throws ProgramScheduledException;
	

}
