package com.capgemini.bratu.service;

import javax.transaction.Transactional;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bratu.entities.ProgramOffered;
import com.capgemini.bratu.entities.Program_Scheduled;
import com.capgemini.bratu.exception.ProgramScheduledException;
import com.capgemini.bratu.repository.ProgramScheduledDAO;
import com.capgemini.bratu.util.Status;

@Service
@Transactional
public class ProgramScheduledServiceImpl implements ProgramScheduledService{

	@Autowired
	ProgramScheduledDAO programScheduledDao;
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public Status save(Program_Scheduled program)
			throws ProgramScheduledException {
		Status status = programScheduledDao.save(program);
		return status;
	}

	@Override
	public Status update(Program_Scheduled program)
			throws ProgramScheduledException {
		Status status = programScheduledDao.findById(program);
		Program_Scheduled programById = null;
		if (status.getCode() == 1) {
			programById = (Program_Scheduled) status.getObject();
		}
		
		
		if (programById != null) {
			
			
			if (program.getCourseName() != null) {
				programById.setCourseName(program.getCourseName());
			}
			
			if (program.getEnd_date() != null) {
				programById.setEnd_date(program.getEnd_date());
			}
			
			if (program.getProgramName() != null) {
				programById.setProgramName(program.getProgramName());
			}
			
			if (program.getSession_per_week() != 0) {
				programById.setSession_per_week(program.getSession_per_week());
			}
			
			if (program.getStart_date() != null) {
				programById.setStart_date(program.getStart_date());
			}
			
			Status updatedProgram = programScheduledDao.update(programById);
			return updatedProgram;
		} else {
			return new Status(0, "Id Not Found", null);
		}
		
		
	}

	@Override
	public Status delete(Program_Scheduled program)
			throws ProgramScheduledException {
		Status status = programScheduledDao.findById(program);
		Program_Scheduled prograToDelete = (Program_Scheduled) status.getObject();
		return programScheduledDao.delete(prograToDelete);
	}

	@Override
	public Status findById(Program_Scheduled program)
			throws ProgramScheduledException {
		Status status = programScheduledDao.findById(program);
		Program_Scheduled programById = (Program_Scheduled) status.getObject();
		
		if (programById != null) {
			return new Status(1, "Prgram Found", programById);
		} else {
			return new Status(0, "Prgram Not Found", programById);
		}
	}

	@Override
	public Status findByName(Program_Scheduled program)
			throws ProgramScheduledException {
		Status status = programScheduledDao.findByName(program);
		Program_Scheduled programByName = (Program_Scheduled) status.getObject();
		
		if (programByName != null) {
			return new Status(1, "Prgram Found", programByName);
		} else {
			return new Status(0, "Prgram Not Found", programByName);
		}
	}

	@Override
	public Status findAll()
			throws ProgramScheduledException {
		return programScheduledDao.findAll();
	}

	@Override
	public Status findByProgramName(Program_Scheduled program)
			throws ProgramScheduledException {
		return programScheduledDao.findByProgramName(program);
	}

}
