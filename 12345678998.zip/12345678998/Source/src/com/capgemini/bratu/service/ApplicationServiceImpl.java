package com.capgemini.bratu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.bratu.entities.Application;
import com.capgemini.bratu.exception.ApplicationException;
import com.capgemini.bratu.repository.ApplicationDao;
import com.capgemini.bratu.util.Status;



@Service
@Transactional
public class ApplicationServiceImpl implements ApplicationService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Autowired
	ApplicationDao appDao ; 
	
	@Override
	public Status update(Application application) throws ApplicationException {
		
		Status appUpdate = appDao.findById(application);
		
		Application application2 = (Application) appUpdate.getObject();
		
		if(application.getDate_of_birth() != null ){
			application2.setDate_of_birth(application.getDate_of_birth()) ;
		}
		
		if(application.getDate_of_interview() != null ){
			application2.setDate_of_interview(application.getDate_of_interview()) ;
		}
		if(application.getFull_name() != null ){
			application2.setFull_name(application.getFull_name());
		}
		if(application.getEmail_id() != null){
			application2.setEmail_id(application.getEmail_id());
		}
		if(application.getGoals() != null){
			application2.setGoals(application.getGoals());
		}
		if(application.getHighest_qualification() != null){
			application2.setHighest_qualification(application.getHighest_qualification());
		}
		if(application.getMarks_obtained() !=null){
			application2.setMarks_obtained(application.getMarks_obtained());
		}
		if(application.getStatus() != null){
			application2.setStatus(application.getStatus());
		}
		
		if(application.getRoll_no() != null){
			application2.setRoll_no(application.getRoll_no());
		}
			
		Status updateApplication = appDao.update(application2);
		if(updateApplication.getCode()==1){
		 return updateApplication;
		}
		else{
			throw new ApplicationException("not updated");
		}
	}

	@Override
	public Status updateStatus(Application application)
			throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Status updateInterview(Application application)
			throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Status findById(Application application) throws ApplicationException {
		// TODO Auto-generated method stub
		return appDao.findById(application);
	}

	@Override
	public Status showAll() throws ApplicationException {
		// TODO Auto-generated method stub
		return appDao.showAll();
	}

	@Override
	public Status delete(Application application) throws ApplicationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Status findByStatus(Application application)
			throws ApplicationException {
		// TODO Auto-generated method stub
		return appDao.findByStatus(application);
	}

	@Override
	public Status save(Application application) throws ApplicationException {
	
		return appDao.save(application);
	}

	@Override
	public Status findByEmail(Application application)
			throws ApplicationException {
	return 	appDao.findByEmail(application);
	
	}

}
