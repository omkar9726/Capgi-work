package com.capgemini.bratu.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bratu.entities.ProgramOffered;
import com.capgemini.bratu.exception.ProgramOfferedException;
import com.capgemini.bratu.repository.ProgramOfferedDAO;
import com.capgemini.bratu.util.Status;

@Service
@Transactional
public class ProgramOfferedServiceImpl implements ProgramOfferedService {

	@Autowired
	ProgramOfferedDAO programOfferedDao;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public Status save(ProgramOffered program) throws ProgramOfferedException {
		
		Status status = programOfferedDao.save(program);
		return status;
	}

	@Override
	public Status update(ProgramOffered program) throws ProgramOfferedException {
		
		Status status = programOfferedDao.fingByName(program);
		
		ProgramOffered programByName = (ProgramOffered) status.getObject();
		
		if (program.getApplicant_eligibility() != null) {
			programByName.setApplicant_eligibility(program.getApplicant_eligibility());
		}
		
		if (program.getDegree_certificate_offered() != null) {
			programByName.setDegree_certificate_offered(program.getDegree_certificate_offered());
		}
		
		
		if (program.getDescription() != null) {
			programByName.setDescription(program.getDescription());
		}
		
		if (program.getDuration() != 0) {
			programByName.setDuration(program.getDuration());
		}
		
		if (program.getProgramName() != null) {
			programByName.setProgramName(program.getProgramName());
		}
		
		Status statusByProgram = programOfferedDao.update(programByName);
		
		if (statusByProgram.getCode() == 1) {
			return new Status(1, "Program Updated", (ProgramOffered) statusByProgram.getObject());
		} else {
			return new Status(0, "Program Not Updated", (ProgramOffered) statusByProgram.getObject());
		}
		
		
	}

	@Override
	public Status delete(ProgramOffered program) throws ProgramOfferedException {
		
		Status status = programOfferedDao.findById(program);
		ProgramOffered programToDelete = (ProgramOffered) status.getObject();
		return programOfferedDao.delete(programToDelete);
	}

	@Override
	public Status findById(ProgramOffered program)
			throws ProgramOfferedException {
		Status status = programOfferedDao.findById(program);
		ProgramOffered programById = (ProgramOffered) status.getObject();
		
		if (programById != null) {
			return new Status(1, "Prgram Found", programById);
		} else {
			return new Status(0, "Prgram Not Found", programById);
		}
		
	}

	@Override
	public Status fingByName(ProgramOffered program)
			throws ProgramOfferedException {
		Status status = programOfferedDao.fingByName(program);
		ProgramOffered programByName = (ProgramOffered) status.getObject();
		
		if (programByName != null) {
			return new Status(1, "Prgram Found", programByName);
		} else {
			return new Status(0, "Prgram Not Found", programByName);
		}
	}

	@Override
	public Status findAll() throws ProgramOfferedException {
		
		return programOfferedDao.findAll();
	}

}
