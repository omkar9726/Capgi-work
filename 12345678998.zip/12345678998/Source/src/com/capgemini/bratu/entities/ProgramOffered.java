package com.capgemini.bratu.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name="bratu_programOffered",  uniqueConstraints = @UniqueConstraint(columnNames ="programName"))
public class ProgramOffered implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private long id;
	
	@Column(name="programName")
	private String programName;
	
	@Column(name="description")
	private String description;
	
	@Column(name="applicant_eligibility")
	private String applicant_eligibility;
	
	@Column(name="duration")
	private long duration;
	
	@Column(name="degree_certificate_offered")
	private String degree_certificate_offered;

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}

	/**
	 * @param programName the programName to set
	 */
	public void setProgramName(String programName) {
		this.programName = programName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the applicant_eligibility
	 */
	public String getApplicant_eligibility() {
		return applicant_eligibility;
	}

	/**
	 * @param applicant_eligibility the applicant_eligibility to set
	 */
	public void setApplicant_eligibility(String applicant_eligibility) {
		this.applicant_eligibility = applicant_eligibility;
	}

	/**
	 * @return the duration
	 */
	public long getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(long duration) {
		this.duration = duration;
	}

	/**
	 * @return the degree_certificate_offered
	 */
	public String getDegree_certificate_offered() {
		return degree_certificate_offered;
	}

	/**
	 * @param degree_certificate_offered the degree_certificate_offered to set
	 */
	public void setDegree_certificate_offered(String degree_certificate_offered) {
		this.degree_certificate_offered = degree_certificate_offered;
	}
	
	
	

}
