package com.capgemini.bratu.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="bratu_application", uniqueConstraints = @UniqueConstraint(columnNames ="email_id"))
public class Application implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	@Column(name="application_id" , length=20)
	private long application_id;
	
	@Column(name="full_name" , length=20)
	private String full_name;
	
	@Column(name="date_of_birth" , length=20)
	private String date_of_birth;
	
	@Column(name="highest_qualification" , length=20)
	private String highest_qualification;
	
	@Column(name="marks_obtained" , length=20)
	private Double marks_obtained;
	
	@Column(name="goals" , length=20)
	private String goals;
	
	@Column(name="email_id" , length=40)
	private String email_id;
	
	@Column(name="Scheduled_program_id" , length=20)
	private long scheduled_program_id;
	
	@Column(name="courseName" , length=20)
	private String courseName;
	
	@Column(name="status" , length=20)
	private String status;
	
	@Column(name="Date_Of_Interview")
	private String date_of_interview;
	
	private String roll_no;

	/**
	 * @return the application_id
	 */
	public long getApplication_id() {
		return application_id;
	}

	

	/**
	 * @return the courseName
	 */
	public String getCourseName() {
		return courseName;
	}



	/**
	 * @param courseName the courseName to set
	 */
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}



	/**
	 * @param application_id the application_id to set
	 */
	public void setApplication_id(long application_id) {
		this.application_id = application_id;
	}

	/**
	 * @return the full_name
	 */
	public String getFull_name() {
		return full_name;
	}

	/**
	 * @param full_name the full_name to set
	 */
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	/**
	 * @return the date_of_birth
	 */
	public String getDate_of_birth() {
		return date_of_birth;
	}

	/**
	 * @param date_of_birth the date_of_birth to set
	 */
	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	/**
	 * @return the highest_qualification
	 */
	public String getHighest_qualification() {
		return highest_qualification;
	}

	/**
	 * @param highest_qualification the highest_qualification to set
	 */
	public void setHighest_qualification(String highest_qualification) {
		this.highest_qualification = highest_qualification;
	}

	/**
	 * @return the marks_obtained
	 */
	public Double getMarks_obtained() {
		return marks_obtained;
	}

	/**
	 * @param marks_obtained the marks_obtained to set
	 */
	public void setMarks_obtained(Double marks_obtained) {
		this.marks_obtained = marks_obtained;
	}

	/**
	 * @return the goals
	 */
	public String getGoals() {
		return goals;
	}

	/**
	 * @param goals the goals to set
	 */
	public void setGoals(String goals) {
		this.goals = goals;
	}

	/**
	 * @return the email_id
	 */
	public String getEmail_id() {
		return email_id;
	}

	/**
	 * @param email_id the email_id to set
	 */
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	/**
	 * @return the scheduled_program_id
	 */
	public long getScheduled_program_id() {
		return scheduled_program_id;
	}

	/**
	 * @param scheduled_program_id the scheduled_program_id to set
	 */
	public void setScheduled_program_id(long scheduled_program_id) {
		this.scheduled_program_id = scheduled_program_id;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	
	public String getDate_of_interview() {
		return date_of_interview;
	}



	public void setDate_of_interview(String date_of_interview) {
		this.date_of_interview = date_of_interview;
	}



	/**
	 * @return the roll_no
	 */
	public String getRoll_no() {
		return roll_no;
	}

	/**
	 * @param roll_no the roll_no to set
	 */
	public void setRoll_no(String roll_no) {
		this.roll_no = roll_no;
	}

	
	
	
}
